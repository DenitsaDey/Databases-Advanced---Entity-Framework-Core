﻿using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XMLHelper;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            //1.
            var usersXml = File.ReadAllText("../../../Datasets/users.xml");
            var result = ImportUsers(context, usersXml);
            System.Console.WriteLine(result);

            //2.
            var productsXml = File.ReadAllText("../../../Datasets/products.xml");
            var result2 = ImportProducts(context, productsXml);
            System.Console.WriteLine(result2);

            //var usersXml = File.ReadAllText("../../../Datasets/users.xml");
            //var result = ImportUsers(context, usersXml);
            //System.Console.WriteLine(result);
        }
        
        //1. Import Users
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Users";

            var userResult = XMLConverter.Deserializer<ImportUserDto>(inputXml, rootElement);

            List<User> users = new List<User>();
            foreach (var dto in userResult)
            {
                User user = new User
                {
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    Age = dto.Age
                };
                users.Add(user);
            }

            //or:
            //var users = userResult
            //    .Select(u => new User
            //    {
            //        FirstName = u.FirstName,
            //        LastName = u.LastName,
            //        Age = u.Age
            //    })
            //    .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}";

        }

        //2. Import Products
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Products";

            var productResult = XMLConverter.Deserializer<ImportProductDto>(inputXml, rootElement);

            List<Product> products = new List<Product>();
            foreach (var dto in productResult)
            {
                Product product = new Product
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    SellerId = dto.SellerId,
                    BuyerId = dto.BuyerId
                };
                products.Add(product);
            }

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count}";
        }

        //3. Import Categories

    }
}