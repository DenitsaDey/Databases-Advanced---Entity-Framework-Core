﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using CarDealer.Data;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        private const string DatasetsDirPath = @"../../../Datasets/";
        private const string ResultDirPath = DatasetsDirPath + "Results/";
        public static void Main(string[] args)
        {
            //Mapper.Initialize(cfg => { cfg.AddProfile<CarDealerProfile>(); });

            using var db = new CarDealerContext();
            //ResetDatabase(db);

            //9.Import Suppliers
            //string inputXml = File.ReadAllText(DatasetsDirPath + "suppliers.xml");
            //string result = ImportSuppliers(db, inputXml);
            //Console.WriteLine(result);

            //10.Import Parts
            //string inputXml = File.ReadAllText(DatasetsDirPath + "parts.xml");
            //string result = ImportParts(db, inputXml);
            //Console.WriteLine(result);

            //11. Import Cars
            string inputXml = File.ReadAllText(DatasetsDirPath + "cars.xml");
            string result = ImportCars(db, inputXml);
            Console.WriteLine(result);

        }

        //9. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var xmlSerializer = new XmlSerializer(typeof(ImportSupplierDto[]), new XmlRootAttribute("Suppliers"));

            ImportSupplierDto[] supplierDtos;

            using(var reader = new StringReader(inputXml))
            {
                supplierDtos = (ImportSupplierDto[])xmlSerializer.Deserialize(reader);
            }

            List<Supplier> suppliers = new List<Supplier>();
            foreach (var dto in supplierDtos)
            {
                Supplier supplier = new Supplier()
                {
                    Name = dto.Name,
                    IsImporter = dto.IsImporter
                };
                suppliers.Add(supplier);
            }
            //when using mapper:
            //var suppliers = Mapper.Map<Supplier[]>(supplierDtos);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }

        //10. Import Parts
        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            var xmlSerializer = new XmlSerializer(typeof(ImportPartDto[]), new XmlRootAttribute("Parts"));

            ImportPartDto[] partDtos;

            using(var reader = new StringReader(inputXml))
            {
                partDtos = ((ImportPartDto[])xmlSerializer
                    .Deserialize(reader))
                    .Where(p=> context.Suppliers.Any(s=>s.Id == p.SupplierId))
                    .ToArray();
            }

            List<Part> parts = new List<Part>();
            foreach (var dto in partDtos)
            {
                Part part = new Part
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    Quantity = dto.Quantity,
                    SupplierId = dto.SupplierId
                };
                parts.Add(part);
            }
            //var parts = Mapper.Map<Part[]>(partDtos);

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }

        //11. Impoert Cars
        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            var xmlSerializer = new XmlSerializer(typeof(ImportCarsDto[]), new XmlRootAttribute("Cars"));

            ImportCarsDto[] carsDtos;

            using (var reader = new StringReader(inputXml))
            {
                carsDtos = ((ImportCarsDto[])xmlSerializer
                    .Deserialize(reader));                    
            }

            List<Car> cars = new List<Car>();
            List<PartCar> partCars = new List<PartCar>();

            foreach (var dto in carsDtos)
            {
                Car car = new Car()
                {
                    Make = dto.Make,
                    Model = dto.Model,
                    TravelledDistance = dto.TravelledDistance,
                };

                var parts = dto.Parts
                    .Where(pc => context.Parts.Any(p => p.Id == pc.Id))
                    .Select(p => p.Id)
                    .Distinct();

                foreach (var part in parts)
                {
                    PartCar partCar = new PartCar()
                    {
                        PartId = part,
                        Car = car
                    };
                    partCars.Add(partCar);
                }
                cars.Add(car);
            }
            //var parts = Mapper.Map<Part[]>(partDtos);

            context.PartCars.AddRange(partCars);
            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }
        private static void ResetDatabase(CarDealerContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("Database successfully deleted!");
            db.Database.EnsureCreated();
            Console.WriteLine("Database successfully created!");
        }
    }
}