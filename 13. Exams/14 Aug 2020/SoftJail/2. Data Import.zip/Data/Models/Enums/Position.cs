﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer = 1,
        Guard = 2,
        Watcher = 3,
        Labour = 4
    }
}
